# famous-organism
Organisms named after famous people in [ColDP](https://github.com/CatalogueOfLife/coldp) format.
Registered with:
 - ChecklistBank at https://www.checklistbank.org/dataset/37354/
 - GBIF at http://www.gbif.org/dataset/00e791be-36ae-40ee-8165-0b2cb0b8c84f

## References
Reference metadata in BibTex from DOIs was retrieved using CrossRef:

> curl --location --silent --header "Accept: application/x-bibtex" https://doi.org/10.1080/11035890601282097

This online tool to tidy bibtex was used: https://flamingtempura.github.io/bibtex-tidy/index.html